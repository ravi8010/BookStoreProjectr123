package com.capgemini.BookStoreProject.service;

import java.util.List;

import com.capgemini.BookStoreProject.beans.Book;

public interface BookService {
public List<Book> allBooks();
public Book createBook(Book book);
public Book delete(int id);
public Book update(Book book);

public Book findBook(int id);


}
