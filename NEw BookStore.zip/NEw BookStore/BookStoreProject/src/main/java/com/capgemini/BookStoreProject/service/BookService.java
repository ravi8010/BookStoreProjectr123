package com.capgemini.BookStoreProject.service;

import java.util.List;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.exceptions.BookAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.ListEmptyException;

public interface BookService {
public List<Book> allBooks() throws ListEmptyException;
public Book createBook(Book book) throws BookAlreadyExistException;
public Book delete(int id) throws   BookIdDoesNotExistException;
public Book update(Book book) throws BookAlreadyExistException;

public Book findBook(int id) throws BookIdDoesNotExistException;


}
