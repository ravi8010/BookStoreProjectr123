package com.capgemini.BookStoreProject.exceptions;

public class BookAlreadyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookAlreadyExistException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
