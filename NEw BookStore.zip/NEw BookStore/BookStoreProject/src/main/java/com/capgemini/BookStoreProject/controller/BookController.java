package com.capgemini.BookStoreProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.exceptions.BookAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.ListEmptyException;
import com.capgemini.BookStoreProject.service.BookService;
import com.capgemini.BookStoreProject.service.CustomerService;
@RestController
public class BookController {
	
	
	@Autowired(required=true) 
	
	private BookService bookService;
	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(method=RequestMethod.GET,value="/books") 
	public List<Book> findAll() throws ListEmptyException{    
		return bookService.allBooks();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/books")
	public Book createBook(@RequestBody Book book) throws BookAlreadyExistException { 
		return bookService.createBook(book);
		}
	
	@RequestMapping(method=RequestMethod.GET,value="/books/{id}") 
	public Book findBook(@PathVariable int id) throws BookIdDoesNotExistException { 
		return bookService.findBook(id);
		}
	
	@RequestMapping(method=RequestMethod.PUT,value="/books")  
	public Book updateBook(@RequestBody Book book) throws BookAlreadyExistException {
		return bookService.update( book);
		}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/books/{id}")
	public Book delete(@PathVariable int id) throws   BookIdDoesNotExistException {
		return bookService.delete(id);
		}	
	
	
	
	@RequestMapping(method=RequestMethod.GET,value="/booksReview/{id}") 
	public List<Review> allReview(@PathVariable int id)
	{
		return customerService.bookReview(id);
		
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/bookInfo/{id}")
	public Book bookInfo(@PathVariable int id)
	{
		return customerService.findInformation(id);
		
	}
	
	

}
