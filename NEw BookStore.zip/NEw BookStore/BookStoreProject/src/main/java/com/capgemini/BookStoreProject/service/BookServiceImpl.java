package com.capgemini.BookStoreProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.dao.BookDao;
import com.capgemini.BookStoreProject.exceptions.BookAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.ListEmptyException;

@Service
public class BookServiceImpl implements BookService {
	
	@Autowired
	private BookDao bookDao;

	@Override
	public List<Book> allBooks() throws ListEmptyException {
		List<Book> allBook=bookDao.findAll();
		if(allBook.isEmpty())
		{
			throw new ListEmptyException("List Is Empty");
		}
			
		return allBook;  

	}

	@Override
	public Book createBook(Book book) throws BookAlreadyExistException {

		List<Book> allBook=bookDao.findAll();
		for(Book book1:allBook)
		{
			if(book1.getTitle().equals(book.getTitle()))
			{
				throw new BookAlreadyExistException("Book ID Already Exist");
			}
		}
		
		return bookDao.saveAndFlush(book);
		

	}

	@Override
	public Book delete(int id) throws  BookIdDoesNotExistException {


		
		List<Book> allBook=bookDao.findAll();
		for(Book book1:allBook)
		{
			if(book1.getBookId()==id)
			{
				bookDao.deleteById(id);
				
			}
		}
		throw new BookIdDoesNotExistException("Book Id Does not Exception");
				
	}

	@Override
	public Book update(Book book) throws BookAlreadyExistException {
		
		List<Book> allBook=bookDao.findAll();
		for(Book book1:allBook)
		{
			if(book1.getBookId()==book.getBookId())
			{
				throw new BookAlreadyExistException("Book ID Already Exist");
			}
		}
		
		
		bookDao.saveAndFlush(book);
		bookDao.flush();
		return book;

	}

	@Override
	public Book findBook(int id) throws BookIdDoesNotExistException {

		if (bookDao.findById(id) == null)
			throw new BookIdDoesNotExistException("Book Id does not Exist");

		return bookDao.findById(id).get();
	}

}
